import json,time,urllib.request
from pathlib import Path
root=Path(__file__).parent;old=root.parent/'2026-10-20-cross-runtime'
def predict(state,instructions,criteria):
 p=dict(model='english',max_len=1024,head_max_len=512,state=state,questions={'answer':dict(type='choice',instructions=instructions,criteria=criteria)})
 req=urllib.request.Request('https://laya-gpu.iambarton.com/v1/systemone',data=json.dumps(p).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as r:answer=json.load(r)
 out.write(json.dumps(dict(request=p,response=answer))+'\n');out.flush();return answer['answers']['answer']['choice']
with (root/'hierarchy.jsonl').open('x') as out:
 tool_kinds={};correct=0;total=0
 for suite in ['sglang-contract','sglang-independent']:
  for c in json.loads((old/suite/'01-first.json').read_text())['suite']['cases']:
   kind=predict(c['task'],'What does the user want to do?',{'read':'Read or look up information.','write':'Create, change or delete stored information.'})
   tools=[]
   for t in c['tools']:
    key=t['server']+'.'+t['name'];cache=(key,t['description'])
    if cache not in tool_kinds:tool_kinds[cache]=predict(key+': '+t['description'],'What does this tool do?',{'read':'Read or look up information.','write':'Create, change or delete stored information.'})
    if tool_kinds[cache]==kind:tools.append(t)
   cs={f'tool_{i}':t['server']+'.'+t['name']+': '+t['description'] for i,t in enumerate(tools)}
   expected=next(t['server']+'.'+t['name'] for t in c['tools'] if t.get('required'))
   if cs:
    choice=predict(c['task'],'Which tool should handle this request?',cs);t=tools[int(choice.split('_')[1])];chosen=t['server']+'.'+t['name']
   else:chosen='none'
   passed=chosen==expected;correct+=passed;total+=1
   print(c['id'],'intent',kind,'tool classes',[(t['name'],tool_kinds[(t['server']+'.'+t['name'],t['description'])]) for t in c['tools']],chosen,passed,flush=True)
 print('initial route',correct,total)
