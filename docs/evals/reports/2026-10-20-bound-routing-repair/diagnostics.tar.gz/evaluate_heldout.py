import hashlib,json,time,urllib.request
from pathlib import Path
root=Path(__file__).parent;data=(root/'heldout.jsonl').read_bytes();manifest=json.loads((root/'training-manifest.json').read_text());assert hashlib.sha256(data).hexdigest()==manifest['heldout']['sha256']
candidate=json.load(urllib.request.urlopen('http://127.0.0.1:8012/health'));assert candidate['sha256']=='11b9ea87a1431a22f1193e494ba34930ecb8e86832112c83ab3779fd7e5d5019'
selection=dict(checkpoint=candidate,development=json.loads((root/'gpu-full-summary.json').read_text())['train_report']['after'],heldout_sha256=manifest['heldout']['sha256'],chosen_before_heldout_predictions=True);(root/'candidate-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
rows=[json.loads(l) for l in data.splitlines()];summaries={}
with (root/'heldout-predictions.jsonl').open('x') as out:
 for name,origin in [('stock-gpu','https://laya-gpu.iambarton.com'),('adapted-cpu','http://127.0.0.1:8012')]:
  correct=0
  for i,row in enumerate(rows):
   payload=dict(model='english',max_len=1024,head_max_len=512,state=row['state'],questions=row['questions']);start=time.monotonic();result=dict(model=name,index=i,expected=row['expected']['tool'],request=payload)
   try:
    req=urllib.request.Request(origin+'/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as res:result['response']=json.load(res)
    result['passed']=result['response']['answers']['tool']['choice']==row['expected']['tool'] and not result['response'].get('usage',{}).get('truncated',False)
   except Exception as e:result['error']=str(e);result['passed']=False
   correct+=result['passed'];result['duration_ms']=round((time.monotonic()-start)*1000,3);out.write(json.dumps(result)+'\n');out.flush()
   if (i+1)%12==0:print(name,i+1,'correct',correct,flush=True)
  summaries[name]=dict(correct=correct,total=len(rows))
(root/'heldout-summary.json').write_text(json.dumps(summaries,indent=2)+'\n');print(summaries,flush=True)
