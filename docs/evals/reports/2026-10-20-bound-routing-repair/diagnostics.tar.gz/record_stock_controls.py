import json,urllib.request
from pathlib import Path
r=Path(__file__).parent;states=['I was billed twice. Please refund the duplicate.','My invoice has the wrong tax amount.','The payment failed and my card was charged.','Please cancel the recurring subscription billing.','The application crashes whenever I save.','The API returns HTTP 500 errors.','Login fails with the correct credentials.','The website is down for all our users.','What is the price of twenty seats?','Can I get a quote for an enterprise contract?','Does the business plan support annual pricing?','Please arrange a product demo for our purchasing team.']
questions={'department':dict(type='choice',instructions='Which team should handle this request?',criteria={'billing':'Invoices, payments and refunds.','technical':'Bugs, outages and integrations.','sales':'Pricing, new contracts and demos.'})}
with (r/'stock-control-before.jsonl').open('x') as out:
 for i,state in enumerate(states):
  payload=dict(model='english',max_len=1024,head_max_len=512,state=state,questions=questions);req=urllib.request.Request('https://laya-gpu.iambarton.com/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'});answer=json.load(urllib.request.urlopen(req,timeout=10));out.write(json.dumps(dict(index=i,request=payload,response=answer))+'\n');out.flush()
print('12 stock-model controls recorded')
