import csv,json,statistics
from collections import defaultdict
from pathlib import Path
r=Path(__file__).parent
rows=[];by=defaultdict(list);write_calls=[]
for stage in ['workflows','bridge-workflows','phase-workflows']:
 for p in sorted((r/stage).glob('*/01-*.json')):
  if p.name.endswith('.metadata.json'):continue
  report=json.loads(p.read_text())
  if 'trials' not in report:continue
  suite,repetition,arm=p.parent.name.rsplit('-',2)
  for t in report['trials']:
   row=dict(stage=stage,suite=suite,arm=arm,repetition=int(repetition),case=t['case_id'],passed=t['grade']['passed'],duration_ms=t['duration_ms'],failed_checks=';'.join(k for k,v in t['grade']['checks'].items() if not v),report=str(p.relative_to(r)))
   rows.append(row);by[(stage,suite,arm)].append(row)
   for call in (t.get('tool_calls') or []):
    if call['tool'].startswith(('update_','delete_','create_')):write_calls.append(dict(stage=stage,suite=suite,arm=arm,repetition=int(repetition),case=t['case_id'],call=call))
summary=[dict(stage=k[0],suite=k[1],arm=k[2],passed=sum(x['passed'] for x in v),total=len(v),median_ms=statistics.median(x['duration_ms'] for x in v)) for k,v in sorted(by.items())]
(r/'workflow-summary.json').write_text(json.dumps(dict(cohorts=summary,write_calls=write_calls),indent=2)+'\n')
with (r/'workflow-trials.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for x in summary:print(x)
print('Synthetic write-tool invocations',len(write_calls))
