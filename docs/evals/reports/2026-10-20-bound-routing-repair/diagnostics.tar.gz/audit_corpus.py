import collections,hashlib,json
from pathlib import Path
from transformers import AutoTokenizer
from laya.common import build_sequence
from laya.agent import Agent
r=Path(__file__).parent;tok=AutoTokenizer.from_pretrained('/home/bbarton/.prism/laya/huggingface/hub/models--convaiinnovations--laya/snapshots/55cf4c4ebb4ebe31b2550e8bdf3bd21b99753851/tokenizer');summary={};seen={}
for name,source in [('train',r/'corpus-v2/train.jsonl'),('development',r/'corpus-v2/development.jsonl'),('heldout',r/'heldout.jsonl')]:
 stats=[];widths=collections.Counter();keys=set()
 for line in source.read_text().splitlines():
  row=json.loads(line);q=Agent._to_internal(row['questions']['tool']);ids,markers,opt,trunc=build_sequence(tok,row['state'],q,max_len=1024,head_max_len=512,return_stats=True,return_truncation_stats=True);stats.append(trunc);widths[len(markers)]+=1
  assert row['expected']['tool'] in row['questions']['tool']['criteria'];keys.add(json.dumps([row['state'],row['questions']],sort_keys=True))
 summary[name]=dict(rows=len(stats),unique_inputs=len(keys),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),truncated_rows=sum(s['truncated'] for s in stats),max_state_tokens=max(s['state_tokens'] for s in stats),max_dropped=max(s['state_tokens_dropped'] for s in stats),option_widths=dict(widths));seen[name]=keys
assert not seen['train']&seen['development'] and not seen['train']&seen['heldout'] and not seen['development']&seen['heldout']
assert all(s['truncated_rows']==0 for s in summary.values())
(r/'corpus-v2/budget-and-overlap-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
