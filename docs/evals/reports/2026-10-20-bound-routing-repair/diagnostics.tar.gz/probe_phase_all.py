import copy,hashlib,json,urllib.request
from pathlib import Path
r=Path(__file__).parent;old=r.parent/'2026-10-20-cross-runtime';wire=[json.loads(l)['request'] for l in (r/'candidate-wire.jsonl').read_text().splitlines()];finish='finish: The retrieved evidence already answers the task, including an explicit access denial or empty result. Finish without repeating completed calls.'
first='Choose the first tool call required by the task. Obtain prerequisite identifiers before following linked records.'
nextq={'records':'Choose the next action needed for the task using the completed results. Finish only after the requested records have been retrieved.','evidence':'Choose the next action needed for the task using the completed results. Finish only after requested evidence is present, including a final empty result or access denial.'}
counts={k:[0,0] for k in nextq}
with (r/'phase-all-probes.jsonl').open('x') as out:
 for suite in ['sglang-contract','sglang-independent']:
  for c in json.loads((old/suite/'01-first.json').read_text())['suite']['cases']:
   base=next(p for p in wire if p['state'].split('TASK:\n',1)[1].split('\nCOMPLETED TOOL EVIDENCE',1)[0]==c['task'] and 'call_mcp_tool:' not in p['state']);needed=[t for t in c['tools'] if t.get('required')]
   for stage in range(len(needed)+1):
    p=copy.deepcopy(base);evidence=''
    for t in needed[:stage]:
     raw=json.dumps(t['response'],separators=(',',':'));data=dict(server=t['server'],tool=t['name'],result_id=hashlib.sha256(raw.encode()).hexdigest()[:32],is_error=t.get('is_error',False),incomplete=False,preview=raw+'\n'+raw,preview_truncated=False,read_with='read_tool_result',original_bytes=len(raw)*2+1,retained_bytes=len(raw)*2+1);evidence+='\ncall_mcp_tool: '+json.dumps(data,indent=2)
    p['state']+=evidence
    if stage:p['questions']['tool']['criteria'][f"tool_{len(p['questions']['tool']['criteria'])}"]=finish
    expected=needed[stage]['server']+'.'+needed[stage]['name'] if stage<len(needed) else 'finish'
    for variant,q in nextq.items():
     payload=copy.deepcopy(p);payload['questions']['tool']['instructions']=q if stage else first;req=urllib.request.Request('http://10.43.199.165:8000/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'});answer=json.load(urllib.request.urlopen(req,timeout=10));choice=answer['answers']['tool']['choice'];selected=payload['questions']['tool']['criteria'][choice].split(':',1)[0];passed=selected==expected;record=dict(case=c['id'],stage=stage,variant=variant,request=payload,response=answer,expected=expected,selected=selected,passed=passed);out.write(json.dumps(record)+'\n');out.flush();counts[variant][0]+=passed;counts[variant][1]+=1
     if not passed:print(c['id'],stage,variant,selected,'expected',expected,flush=True)
print(counts)
