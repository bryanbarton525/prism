import json,subprocess,time,urllib.request
from pathlib import Path
r=Path(__file__).parent
origins={'stock':'https://laya-gpu.iambarton.com','routing':'https://laya-routing.iambarton.com'}
for attempt in range(90):
 try:
  health={k:json.load(urllib.request.urlopen(v+'/health',timeout=5)) for k,v in origins.items()}
  assert all(x['checkpoint_devices']['english'].startswith('cuda') and x['cpu_fallbacks']['english']['count']==0 for x in health.values())
  assert health['routing']['revisions']['english']=='local-sha256:1920ee68f11b2d657b8500448f31c0ff8d56e8eca2913e978991ae3c7bb7c991'
  break
 except Exception as e:print('waiting',str(e),flush=True);time.sleep(2)
else:raise RuntimeError('Final endpoints not healthy')
(r/'final-endpoint-health-before.json').write_text(json.dumps(health,indent=2)+'\n')
rows=[json.loads(x) for x in (r/'phase-all-probes.jsonl').read_text().splitlines()]
picked=[next(x for x in rows if x['case']==c and x['stage']==st and x['variant']=='records') for c,st in [('ops-owner',0),('linked-cycle',0),('linked-project',1)]]
with (r/'local-routing-mcp-predictions.jsonl').open('x') as out:
 for row in picked:
  p=row['request'];p['state']={'text':p['state']};command=['prism','mcp','call','laya-routing','laya_predict','--args-json',json.dumps(p)];call=subprocess.run(command,capture_output=True,text=True,timeout=60);record=dict(case=row['case'],stage=row['stage'],expected=row['expected'],request=p,returncode=call.returncode,stdout=call.stdout,stderr=call.stderr);out.write(json.dumps(record)+'\n');out.flush();assert call.returncode==0,record;print(row['case'],row['stage'],call.stdout[-140:],flush=True)
status=subprocess.run(['prism','mcp','call','laya-routing','laya_status'],capture_output=True,text=True,check=True,timeout=60);(r/'local-routing-mcp-status.json').write_text(status.stdout)
# The gate is written only after the actual MCP transport probes finish.
(r/'mcp-image-ready.json').write_text(json.dumps(dict(health=health,observed=time.time()),indent=2)+'\n')
