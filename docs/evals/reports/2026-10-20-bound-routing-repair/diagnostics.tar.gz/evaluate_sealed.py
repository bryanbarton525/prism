import hashlib,json,time,urllib.request
from pathlib import Path
r=Path(__file__).parent;data=(r/'sealed-validation-v3.jsonl').read_bytes();meta=json.loads((r/'sealed-validation-v3-manifest.json').read_text());assert hashlib.sha256(data).hexdigest()==meta['sha256']
url='http://10.43.199.165:8000'
for attempt in range(180):
 try:
  health=json.load(urllib.request.urlopen(url+'/health',timeout=3));break
 except Exception:time.sleep(2)
else:raise RuntimeError('Candidate GPU inference did not become ready')
assert health['device'].startswith('cuda') and health['weight_dtype']=='torch.float16',health
(r/'curriculum-candidate-selection.json').write_text(json.dumps(dict(checkpoint=health,validation=meta,selected_before_predictions=True),indent=2)+'\n')
rows=[json.loads(l) for l in data.splitlines()];summary={}
with (r/'sealed-validation-predictions.jsonl').open('x') as out:
 for name,origin in [('stock-gpu','https://laya-gpu.iambarton.com'),('curriculum-gpu',url)]:
  correct=0
  for row in rows:
   p={k:row[k] for k in ['state','questions']};p.update(model='english',max_len=1024,head_max_len=512);start=time.monotonic();record=dict(model=name,id=row['id'],reverse=row['reverse'],expected=row['expected']['tool'],request=p)
   try:
    req=urllib.request.Request(origin+'/v1/systemone',data=json.dumps(p).encode(),headers={'Content-Type':'application/json'})
    answer=json.load(urllib.request.urlopen(req,timeout=10));record['response']=answer;record['passed']=answer['answers']['tool']['choice']==row['expected']['tool'] and not answer.get('usage',{}).get('truncated',False)
   except Exception as e:record['error']=str(e);record['passed']=False
   correct+=record['passed'];record['duration_ms']=round((time.monotonic()-start)*1000,3);out.write(json.dumps(record)+'\n');out.flush()
  summary[name]=dict(correct=correct,total=len(rows));print(name,correct,'/',len(rows),flush=True)
(r/'sealed-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
