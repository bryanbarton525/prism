import json,subprocess,time,urllib.request
from pathlib import Path
root=Path(__file__).parent;repo=Path('/tmp/prism-laya-evals');dest=root/'workflows';dest.mkdir(exist_ok=False)
plans=[]
for repetition in range(1,4):
 models=[('stock','https://laya-gpu.iambarton.com'),('adapted','http://127.0.0.1:8012')]
 if repetition%2==0:models.reverse()
 for suite_name,suite in [('original',repo/'evals/mcp-response-v2/suite.yaml'),('independent',repo/'evals/mcp-independent-routing-v1/suite.yaml')]:
  for model,url in models:
   out=dest/f'{suite_name}-{repetition:02d}-{model}';cmd=['python3',str(repo/'evals/run_cluster_matrix.py'),'--engine','sglang','--url','http://10.43.88.30:8080/v1','--model','Qwen3-8B-AWQ','--arms','first','--repeat','1','--laya-url',url,'--suite',str(suite),'--output-dir',str(out)];plans.append(dict(suite=suite_name,model=model,repetition=repetition,command=cmd,output=str(out)))
(root/'workflow-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
for block in plans:
 print('START',block['suite'],block['model'],block['repetition'],flush=True)
 with (root/(Path(block['output']).name+'-runner.log')).open('x') as log:subprocess.run(block['command'],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 report=json.loads((Path(block['output'])/'01-first.json').read_text());print('RESULT',block['suite'],block['model'],block['repetition'],sum(t['grade']['passed'] for t in report['trials']),'/',len(report['trials']),flush=True)
