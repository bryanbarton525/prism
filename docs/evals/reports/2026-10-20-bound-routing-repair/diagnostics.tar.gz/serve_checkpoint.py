"""Loopback-only, sequential accuracy harness for a local Laya checkpoint."""
import argparse,hashlib,json,time
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
import torch,laya
p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True,type=Path);p.add_argument('--port',type=int,default=8012);p.add_argument('--journal',required=True,type=Path);a=p.parse_args()
torch.set_num_threads(2)
sha=hashlib.sha256((a.checkpoint/'model.safetensors').read_bytes()).hexdigest();agent=laya.load(str(a.checkpoint),device='cpu');journal=a.journal.open('x')
class Handler(BaseHTTPRequestHandler):
 def send(self,status,payload):
  data=json.dumps(payload).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  self.send(200,dict(status='ok',device=str(agent.device),checkpoint=str(a.checkpoint),sha256=sha))
 def do_POST(self):
  if self.path!='/v1/systemone':return self.send(404,dict(error='not found'))
  start=time.monotonic()
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n>1048576:return self.send(413,dict(error='body too large'))
   payload=json.loads(self.rfile.read(n));answer=agent.predict(payload['state'],payload['questions'],max_len=payload.get('max_len',1024),head_max_len=payload.get('head_max_len',512));journal.write(json.dumps(dict(request=payload,response=answer,checkpoint_sha256=sha,duration_ms=round((time.monotonic()-start)*1000,2)))+'\n');journal.flush();self.send(200,answer)
  except Exception as e:self.send(500,dict(error=type(e).__name__+': '+str(e)))
HTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
