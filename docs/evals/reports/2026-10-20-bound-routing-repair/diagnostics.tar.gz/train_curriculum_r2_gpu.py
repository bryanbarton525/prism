import gzip,json,os,time
from pathlib import Path
import torch
from laya.train import TrainConfig,finetune
import shutil
assert shutil.disk_usage('/artifacts').free>4*1024**3, 'Need 4 GiB free before checkpoint saves'
root=Path('/artifacts/routing-adaptation/2026-10-20-curriculum-r2');root.mkdir(parents=True,exist_ok=False)
for name in ['train','development','heldout']:(root/(name+'.jsonl')).write_bytes(gzip.decompress((Path('/experiment')/(name+'.jsonl.gz')).read_bytes()))

torch.set_num_threads(2);torch.manual_seed(1049);assert torch.cuda.is_available(),'GPU required';assert torch.cuda.mem_get_info()[0]>10*1024**3,'Insufficient free GPU memory'
c=TrainConfig(epochs=2,micro_batch=2,grad_accum=4,freeze_encoder=False,encoder_lr=0.000005,loss='soft-ce',head_lr=0.00005,shuffle_options=('choice',),max_len=1024,head_max_len=512,calib_frac=0.125,eval_data=str(root/'development.jsonl'),seed=1049,log_every=16)
base='/artifacts/routing-adaptation/2026-10-20-full/checkpoint'
import hashlib
assert hashlib.sha256((Path(base)/'model.safetensors').read_bytes()).hexdigest()=='11b9ea87a1431a22f1193e494ba34930ecb8e86832112c83ab3779fd7e5d5019'
print('RUNTIME',torch.__version__,torch.cuda.get_device_name(),flush=True);start=time.monotonic()
result=finetune(str(root/'train.jsonl'),base,str(root/'checkpoint'),c,device='cuda');result.update(wall_seconds=time.monotonic()-start,gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated(),gpu_peak_reserved_bytes=torch.cuda.max_memory_reserved());(root/'training-summary.json').write_text(json.dumps(result,indent=2));print('TRAINING COMPLETE',json.dumps(result),flush=True)

import gc,laya
from http.server import SimpleHTTPRequestHandler,HTTPServer
gc.collect();torch.cuda.empty_cache()
checkpoint=root/'checkpoint';digest=hashlib.sha256((checkpoint/'model.safetensors').read_bytes()).hexdigest()
agent=laya.load(str(checkpoint),device='cuda',expected_sha256={'model.safetensors':digest})
assert str(agent.device).startswith('cuda'), 'Inference must remain on GPU'
for parameter in agent.model.parameters():
 if parameter.is_floating_point():parameter.data=parameter.data.to(torch.float16)
torch.cuda.empty_cache()
journal=(root/'inference-wire.jsonl').open('x')
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(root),**kwargs)
 def send_json(self,status,payload):
  data=json.dumps(payload).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if self.path=='/health':return self.send_json(200,dict(status='ok',device=str(agent.device),sha256=digest,model='routing-curriculum-v3',wire_model='english',weight_dtype=str(next(agent.model.parameters()).dtype)))
  return super().do_GET()
 def do_POST(self):
  if self.path!='/v1/systemone':return self.send_json(404,dict(error='not found'))
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n>1048576:return self.send_json(413,dict(error='body too large'))
   payload=json.loads(self.rfile.read(n));start=time.monotonic();answer=agent.predict(payload['state'],payload['questions'],max_len=payload.get('max_len',1024),head_max_len=payload.get('head_max_len',512));journal.write(json.dumps(dict(request=payload,response=answer,sha256=digest,duration_ms=round((time.monotonic()-start)*1000,2)))+'\n');journal.flush();self.send_json(200,answer)
  except Exception as e:self.send_json(500,dict(error=type(e).__name__+': '+str(e)))
print('INFERENCE READY',digest,flush=True)
HTTPServer(('0.0.0.0',8000),Handler).serve_forever()
