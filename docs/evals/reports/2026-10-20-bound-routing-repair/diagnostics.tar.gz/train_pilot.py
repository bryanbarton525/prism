import json,time,torch
from pathlib import Path
from laya.train import TrainConfig,finetune
root=Path(__file__).parent;torch.set_num_threads(2);torch.manual_seed(1049)
rows=(root/'train.jsonl').read_text().splitlines();(root/'pilot-train.jsonl').write_text('\n'.join(rows[:192])+'\n')
c=TrainConfig(epochs=2,micro_batch=4,grad_accum=1,freeze_encoder=True,loss='soft-ce',head_lr=0.0002,shuffle_options=('choice',),max_len=1024,head_max_len=512,calib_frac=0.125,eval_data=str(root/'development.jsonl'),seed=1049,log_every=4)
base='/home/bbarton/.prism/laya/huggingface/hub/models--convaiinnovations--laya/snapshots/55cf4c4ebb4ebe31b2550e8bdf3bd21b99753851'
start=time.monotonic();result=finetune(str(root/'pilot-train.jsonl'),base,str(root/'pilot-checkpoint'),c,device='cpu');result['wall_seconds']=time.monotonic()-start;(root/'pilot-training-summary.json').write_text(json.dumps(result,indent=2))
