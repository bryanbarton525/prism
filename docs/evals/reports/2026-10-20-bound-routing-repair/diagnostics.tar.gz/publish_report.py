import csv,gzip,hashlib,json,re,tarfile
from collections import Counter
from pathlib import Path
r=Path(__file__).parent;dest=Path('/tmp/prism-laya-evals/docs/evals/reports/2026-10-20-bound-routing-repair');dest.mkdir(exist_ok=True)
summary=json.loads((r/'workflow-summary.json').read_text());final={(x['suite'],x['arm']):x for x in summary['cohorts'] if x['stage']=='phase-workflows'}
assert len(final)==6 and all(x['total']==18 for x in final.values())
assert all(final[(suite,'adapted')]['passed']==18 for suite in ['original','independent'])
resources=json.loads((r/'final-workflow-resource-summary.json').read_text())
valid=json.loads((r/'report-validation.json').read_text());assert len(valid)==150 and sum(x['trials'] for x in valid)==900 and all(x['returncode']==0 for x in valid)
# Preserve every completed trial and journal; exported/state copies are redundant.
workflow_files=[]
for name in ['baseline-owner','workflows','bridge-workflows','phase-workflows']:
 for p in (r/name).rglob('*'):
  relative=p.relative_to(r)
  if p.is_file() and not any(x=='state' or x.endswith('-export') for x in relative.parts):workflow_files.append(p)
training_dirs=['aborted-corpus-v0','cpu-pilot-timing','corpus-v2','corpus-v3']
diagnostic_files=[p for p in r.iterdir() if p.is_file() and p.stat().st_size<10*1024**2 and p.suffix not in ['.gz']]
for name in training_dirs:diagnostic_files.extend(p for p in (r/name).rglob('*') if p.is_file() and p.stat().st_size<10*1024**2)
# Targeted credential scan; never include transient Argo/registry auth or weights.
patterns=[rb'gh[pousr]_[A-Za-z0-9]{24,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{20,}']
for p in workflow_files+diagnostic_files:
 data=p.read_bytes()
 if any(re.search(pattern,data) for pattern in patterns):raise RuntimeError('Credential-like material in '+str(p.relative_to(r)))
archives=[]
for filename,files in [('workflows.tar.gz',workflow_files),('diagnostics.tar.gz',diagnostic_files)]:
 files=sorted(set(files));target=dest/filename
 with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
  for p in files:
   info=archive.gettarinfo(str(p),arcname=str(p.relative_to(r)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with p.open('rb') as content:archive.addfile(info,content)
 with tarfile.open(target) as archive:
  members=archive.getmembers();assert len(members)==len(files)
  for member,p in zip(members,files):assert hashlib.sha256(archive.extractfile(member).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
 archives.append(dict(file=filename,entries=len(files),bytes=target.stat().st_size))
for name in ['workflow-summary.json','workflow-trials.csv','final-workflow-resource-summary.json']:(dest/name).write_bytes((r/name).read_bytes())
try:
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained');xs=[0,1];arms=[('off','Routing off','#7b8794'),('stock','Stock Laya','#db8a38'),('adapted','Adapted Laya','#248b82')]
 for i,(arm,label,color) in enumerate(arms):
  vals=[final[(suite,arm)]['passed'] for suite in ['original','independent']];bars=ax.bar([x+(i-1)*.23 for x in xs],vals,width=.21,label=label,color=color);ax.bar_label(bars,labels=[str(v)+'/18' for v in vals],padding=4,fontsize=10)
 ax.set_xticks(xs,['Original workflows','Second workflow suite']);ax.set_ylim(0,20);ax.set_yticks([0,3,6,9,12,15,18]);ax.set_ylabel('Passing workflow trials');ax.set_title('Repeated GPU workflows: six cases × three repetitions');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=3,frameon=False,fontsize=9);fig.savefig(dest/'workflow-results.png',dpi=150);plt.close(fig)
except ImportError:raise RuntimeError('matplotlib required to render report')
table='| Suite | Routing off | Stock Laya, bound | Adapted Laya + fixes, bound |\n|---|---:|---:|---:|\n'
for suite,label in [('original','Original'),('independent','Initially independent')]:table+='| '+label+' | '+' | '.join(str(final[(suite,arm)]['passed'])+'/18' for arm in ['off','stock','adapted'])+' |\n'
writes=Counter((x['stage'],x['arm']) for x in summary['write_calls'])
analysis=f'''The adapted arm passed **36/36**, compared with **9/36** for stock bound routing
and **16/36** with routing off in this matched matrix. Each adapted case passed all
three repetitions. This is a repair of the observed integration failures, with
the generalization limits below. The final stock arm dispatched {writes[('phase-workflows','stock')]} synthetic
write-tool calls, and the adapted arm dispatched {writes[('phase-workflows','adapted')]}. Together with the earlier
bridge matrix, this follow-up retains {len(summary['write_calls'])} synthetic write-tool invocations; none
contacted real records. Faster failures are not a useful latency advantage.
Minimum free GPU memory was {resources['gpu_min_free_mib']} MiB and minimum available host memory
was {resources['host_min_available_gib']:.2f} GiB across {resources['samples']} telemetry samples.

![Repeated GPU workflow correctness](workflow-results.png)'''
artifacts='| File | Contents |\n|---|---|\n'
for a in archives:artifacts+=f"| [{a['file']}]({a['file']}) | {a['entries']} verified entries, {a['bytes']:,} bytes |\n"
artifacts+='| [workflow-trials.csv](workflow-trials.csv) | 252 scored follow-up trials, per-case checks and report paths |\n| [workflow-summary.json](workflow-summary.json) | All stage totals and every synthetic write-tool invocation |\n| [final-workflow-resource-summary.json](final-workflow-resource-summary.json) | Final telemetry minima |'
text=(r/'report-template.md').read_text().replace('__FINAL_TABLE__',table).replace('__FINAL_ANALYSIS__',analysis).replace('__ARTIFACT_TABLE__',artifacts)
for suite,token in [('original','ORIG'),('independent','IND')]:
 for arm,prefix in [('stock','STOCK'),('adapted','ADAPT')]:text=text.replace('__'+prefix+'_'+token+'__',str(final[(suite,arm)]['passed']))
text=text.replace('__VALIDATION__','The final CLI validated/exported **150 complete reports covering 900 scored trials**: the previous 648 and this follow-up’s 252. All report hashes/grader checks remained valid.').replace('including a captured red-to-green run.','with no grading-oracle changes.').replace('also discovers the server and accesses its status through the bridge.','also discovers the server and passes all three predictions through `call_mcp_tool`.')
assert not re.search(r'__[A-Z_]+__',text)
(dest/'README.md').write_text(text)
files=sorted(p for p in dest.iterdir() if p.is_file() and p.name!='SHA256SUMS');(dest/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
print(json.dumps(dict(archives=archives,scored_trials=252,verified_reports=len(valid),final_gpu_trials=108),indent=2))
