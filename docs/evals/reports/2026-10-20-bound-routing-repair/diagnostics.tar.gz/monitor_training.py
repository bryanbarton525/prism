import json,os,signal,sys,time
from pathlib import Path
pid=int(sys.argv[1]);dest=Path(sys.argv[2])
with dest.open('x') as out:
 while Path('/proc/'+str(pid)).exists():
  vals={n:int(v.split()[0])*1024 for n,v in (l.split(':',1) for l in Path('/proc/meminfo').read_text().splitlines()) if n in ['MemAvailable','SwapFree']}
  row=dict(time=time.time(),pid=pid,**vals);out.write(json.dumps(row)+'\n');out.flush()
  if vals['MemAvailable']<2*1024**3:
   os.kill(pid,signal.SIGTERM);print('Training stopped: host available memory below 2 GiB',flush=True);break
  time.sleep(2)
