import json,subprocess,time
from pathlib import Path
r=Path(__file__).parent;k=['kubectl','--kubeconfig','/home/bbarton/.kube/k3s-deploy.yaml'];out=(r/'curriculum-r2-training-resources.jsonl').open('x')
while True:
 mem={n:int(v.split()[0])*1024 for n,v in (l.split(':',1) for l in Path('/proc/meminfo').read_text().splitlines()) if n in ['MemAvailable','SwapFree']}
 gpu=subprocess.check_output(['nvidia-smi','--query-gpu=memory.used,memory.free','--format=csv,noheader,nounits'],text=True);used,free=map(int,gpu.strip().split(','));out.write(json.dumps(dict(time=time.time(),host_memory=mem,gpu_used_mib=used,gpu_free_mib=free))+'\n');out.flush()
 result=subprocess.run(k+['get','job','laya-routing-curriculum-r2','-n','laya','-o','json'],capture_output=True,text=True)
 if result.returncode:break
 status=json.loads(result.stdout).get('status',{})
 if status.get('failed'):print('Training job failed',status,flush=True);break
 if mem['MemAvailable']<2*1024**3 or free<96:
  (r/'resource-stop.json').write_text(json.dumps(dict(time=time.time(),memory=mem,gpu_free_mib=free)))
  subprocess.run(k+['logs','-n','laya','job/laya-routing-curriculum-r2'],stdout=(r/'resource-stop-training.log').open('w'))
  subprocess.run(k+['delete','job','laya-routing-curriculum-r2','-n','laya','--wait=false']);break
 time.sleep(2)
