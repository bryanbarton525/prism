import asyncio,json
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
r=Path(__file__).parent
async def main():
 with (r/'fresh-prism-mcp-host.stderr.log').open('w') as errors:
  async with stdio_client(StdioServerParameters(command='prism',args=['mcp','serve']),errlog=errors) as (read,write):
   async with ClientSession(read,write) as session:
    await session.initialize();listing=await session.list_tools();tools={x.name:x for x in listing.tools};(r/'fresh-prism-mcp-host-tools.json').write_text(json.dumps({k:v.input_schema for k,v in tools.items()},indent=2)+'\n')
    for name,args in [('list_mcp_servers',{}),('list_mcp_server_tools',{'server':'laya-routing','include_schema':True}),('call_mcp_tool',{'server':'laya-routing','tool':'laya_status','arguments':{}})]:
     result=await session.call_tool(name,args);(r/('fresh-prism-'+name+'.json')).write_text(result.model_dump_json(indent=2)+'\n');assert not result.is_error,result;print(name,'OK',flush=True)
asyncio.run(main())
