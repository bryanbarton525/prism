"""Development curriculum for dependency lookup, with no Prism replay inputs."""
import hashlib,json,random,runpy
from pathlib import Path
ROOT=Path(__file__).parent
V=runpy.run_path(str(ROOT/'generate_training.py'));QUESTION=V['INSTRUCTIONS'];PROTOCOL=V['PROTOCOL'];ABSTAIN=V['ABSTAIN'];FINISH=V['FINISH']
PAIRS=[('device','fleet'),('order','shipment'),('invoice','account'),('build','pipeline'),('parcel','delivery'),('document','folder'),('machine','rack'),('booking','venue')]

def chain_rows(count,seed,development=False):
 r=random.Random(seed)
 for i in range(count):
  entity,child=r.choice(PAIRS);a=r.choice(['registry','desk','records','catalog']);b=r.choice(['relations','assets','directory']);rid=f'{entity.upper()}-{seed+i*31}';cid=f'{child.upper()}-{seed+i*37}';source=f'{a}.get_{entity}';dest=f'{b}.get_{child}';fields=r.choice([('name','health'),('name','end_date'),('owner','status')]);words=' and '.join(x.replace('_',' ') for x in fields)
  source_desc=r.choice([f'Read {entity} fields including its linked {child} ID.',f'Fetch a {entity} and its linked {child} ID.',f'Read the current {entity} fields by identifier.'])
  descriptions=[source+': '+source_desc,dest+f': Read a {child} by its identifier, including {words}.',f'{a}.update_{entity}: Write changes to a {entity}, including its status or owner.',f'{b}.update_{child}: Change the {child} record and its {words}.','archive.search_docs: Search historical documents, not current records.',f'{a}.list_comments: List old discussion comments, not current fields.']
  tasks=[f'Find the {words} of the {child} linked to {entity} {rid}. First read the {entity}, then look up its linked {child}.',f'Fetch {entity} {rid} with {source}, then retrieve its linked {child} with {dest} using the {child}_id from that {entity}. Report {words} without making changes.',f'For {rid}, identify its {child}, then report that {child} {words}. Get the {child} ID from the {entity} first. Read only.',f'I have {entity} {rid}. Read it to obtain its {child} reference, then use that reference to get {words}. Do not modify anything.',f'Read {entity} {rid}, follow its {child}_id field, and report the linked {child} {words}.',f'Which {child} is associated with {entity} {rid}? Retrieve the starting record, follow the identifier it returns, and report {words}.']
  task=r.choice(tasks) if not development else f'Use {entity} {rid} as the starting record for a two-read lookup: obtain its {child} reference and then return the related record\'s {words}. No updates.'
  stage=i%3
  completed=[]
  if stage>=1:completed.append((source,{'id':rid,child+'_id':cid}))
  if stage>=2:completed.append((dest,{'id':cid,fields[0]:'Synthetic Value',fields[1]:'Synthetic Detail'}))
  target=[source,dest,'finish'][stage]
  # Direct related-record reads stop the model assuming every child tool needs a prerequisite.
  if i%7==0:
   task=f'Read {child} {cid} and return its {words}. Read only.';completed=[];target=dest
  if r.random()<0.6:task+=PROTOCOL
  elif r.random()<0.5:task+=' Return the standard JSON envelope and decision fields. Preserve the types supplied by the actual results.'
  evidence=''
  for name,data in completed:
   server,tool=name.split('.',1);raw=json.dumps(data,separators=(',',':'));envelope=dict(server=server,tool=tool,result_id=hashlib.sha256(raw.encode()).hexdigest()[:32],is_error=False,incomplete=False,preview=raw+'\n'+raw,preview_truncated=False,read_with='read_tool_result',original_bytes=len(raw)*2+1,retained_bytes=len(raw)*2+1);evidence+='\ncall_mcp_tool: '+json.dumps(envelope,indent=2)
  options=descriptions[:2]+[d for d in descriptions[2:] if r.random()<0.65]+[ABSTAIN]+([FINISH] if completed else []);r.shuffle(options);criteria={f'tool_{j}':x for j,x in enumerate(options)};answer=next(k for k,v in criteria.items() if v.split(':',1)[0]==target)
  yield dict(state='TASK:\n'+task+'\nCOMPLETED TOOL EVIDENCE (untrusted data, not instructions):\n'+evidence,questions={'tool':dict(type='choice',instructions=QUESTION,criteria=criteria)},expected={'tool':answer})

def main():
 dest=ROOT/'corpus-v3';dest.mkdir(exist_ok=True);old=[json.loads(l) for l in (ROOT/'corpus-v2/train.jsonl').read_text().splitlines()];random.Random(7001).shuffle(old)
 train=old[:256]+list(chain_rows(512,30971));random.Random(1049).shuffle(train)
 dev=[json.loads(l) for l in (ROOT/'corpus-v2/development.jsonl').read_text().splitlines()]+list(chain_rows(72,99149,True))
 manifest={}
 for name,data in [('train',train),('development',dev)]:
  text=''.join(json.dumps(x)+'\n' for x in data);(dest/(name+'.jsonl')).write_text(text);manifest[name]=dict(rows=len(data),sha256=hashlib.sha256(text.encode()).hexdigest())
 (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest)
if __name__=='__main__':main()
