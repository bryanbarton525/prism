import json,os,re,subprocess,time
from pathlib import Path
r=Path(__file__).parent;tag='ghcr.io/bryanbarton525/laya:sha-6d46972b970b779ac3d4a2812855782283be2ddb';env=dict(os.environ,DOCKER_CONFIG='/tmp/prism-laya-registry-auth')
for _ in range(180):
 p=subprocess.run(['docker','buildx','imagetools','inspect',tag],env=env,capture_output=True,text=True)
 m=re.search(r'^Digest:\s+(sha256:[a-f0-9]{64})\s*$',p.stdout,re.M)
 if p.returncode==0 and m:
  (r/'published-routing-image-mcp.json').write_text(json.dumps(dict(tag=tag,digest=m.group(1),observed=time.time()),indent=2)+'\n');print('Published image verified:',m.group(1),flush=True);break
 time.sleep(5)
else:raise RuntimeError('Image not published within observation window')
