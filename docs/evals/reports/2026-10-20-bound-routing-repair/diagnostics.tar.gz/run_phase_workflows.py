import json,subprocess,time,urllib.request
from pathlib import Path
root=Path(__file__).parent;repo=Path('/tmp/prism-laya-evals');dest=root/'phase-workflows';dest.mkdir(exist_ok=False)
while not (root/'mcp-image-ready.json').exists():
 time.sleep(2)
plans=[]
models=[('off',None),('stock','https://laya-gpu.iambarton.com'),('adapted','https://laya-routing.iambarton.com')]
for repetition in range(1,4):
 ordered=models[repetition-1:]+models[:repetition-1]
 for suite_name,suite in [('original',repo/'evals/mcp-response-v2/suite.yaml'),('independent',repo/'evals/mcp-independent-routing-v1/suite.yaml')]:
  for model,url in ordered:
   arm='off' if url is None else 'first';out=dest/f'{suite_name}-{repetition:02d}-{model}';cmd=['python3',str(repo/'evals/run_cluster_matrix.py'),'--prism',str(root/'prism-phase'),'--engine','sglang','--url','http://10.43.88.30:8080/v1','--model','Qwen3-8B-AWQ','--arms',arm,'--repeat','1','--suite',str(suite),'--output-dir',str(out)]
   if url:cmd+=['--laya-url',url]
   plans.append(dict(suite=suite_name,model=model,repetition=repetition,command=cmd,output=str(out),arm=arm))
(root/'phase-workflow-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
for block in plans:
 print('START',block['suite'],block['model'],block['repetition'],flush=True)
 with (root/('phase-'+Path(block['output']).name+'-runner.log')).open('x') as log:subprocess.run(block['command'],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 report=json.loads((Path(block['output'])/('01-'+block['arm']+'.json')).read_text());print('RESULT',block['suite'],block['model'],block['repetition'],sum(t['grade']['passed'] for t in report['trials']),'/',len(report['trials']),flush=True)
