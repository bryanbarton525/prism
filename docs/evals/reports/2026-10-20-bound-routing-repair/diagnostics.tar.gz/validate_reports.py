import json,subprocess
from pathlib import Path
r=Path(__file__).parent;roots=[r.parent/'2026-10-20-cross-runtime',r/'workflows',r/'bridge-workflows',r/'phase-workflows'];records=[]
(r/'validation-exports-final').mkdir(exist_ok=True)
for root in roots:
 for p in sorted(root.glob('*/[0-9][0-9]-*.json')):
  data=json.loads(p.read_text())
  if 'trials' not in data:continue
  dest=r/'validation-exports-final'/str(len(records));result=subprocess.run([str(r/'prism-phase'),'eval','export',str(p),'--output',str(dest)],capture_output=True,text=True);records.append(dict(report=str(p),trials=len(data['trials']),returncode=result.returncode,stdout=result.stdout,stderr=result.stderr));assert result.returncode==0,records[-1]
(r/'report-validation.json').write_text(json.dumps(records,indent=2)+'\n');print('Validated',len(records),'reports',sum(x['trials'] for x in records),'trials')
