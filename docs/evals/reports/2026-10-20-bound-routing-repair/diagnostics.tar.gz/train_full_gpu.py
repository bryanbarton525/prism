import gzip,json,os,time
from pathlib import Path
import torch
from laya.train import TrainConfig,finetune
root=Path('/data/routing-adaptation/2026-10-20-full');root.mkdir(parents=True,exist_ok=False)
for name in ['train','development','heldout']:(root/(name+'.jsonl')).write_bytes(gzip.decompress((Path('/experiment')/(name+'.jsonl.gz')).read_bytes()))

torch.set_num_threads(2);torch.manual_seed(1049);assert torch.cuda.is_available(),'GPU required';assert torch.cuda.mem_get_info()[0]>10*1024**3,'Insufficient free GPU memory'
c=TrainConfig(epochs=4,micro_batch=2,grad_accum=4,freeze_encoder=False,encoder_lr=0.00001,loss='soft-ce',head_lr=0.0001,shuffle_options=('choice',),max_len=1024,head_max_len=512,calib_frac=0.125,eval_data=str(root/'development.jsonl'),seed=1049,log_every=16)
base='/data/huggingface/hub/models--convaiinnovations--laya/snapshots/55cf4c4ebb4ebe31b2550e8bdf3bd21b99753851'
print('RUNTIME',torch.__version__,torch.cuda.get_device_name(),flush=True);start=time.monotonic()
result=finetune(str(root/'train.jsonl'),base,str(root/'checkpoint'),c,device='cuda');result.update(wall_seconds=time.monotonic()-start,gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated(),gpu_peak_reserved_bytes=torch.cuda.max_memory_reserved());(root/'training-summary.json').write_text(json.dumps(result,indent=2));print('TRAINING COMPLETE',json.dumps(result),flush=True)
