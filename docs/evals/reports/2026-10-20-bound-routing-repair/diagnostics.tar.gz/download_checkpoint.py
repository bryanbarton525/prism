import hashlib,json,time,urllib.request
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin,urlparse
root=Path(__file__).parent;origin='http://10.43.200.191:8000/'
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,tag,attrs):
  if tag=='a':self.links += [v for k,v in attrs if k=='href']
for attempt in range(240):
 try:
  with urllib.request.urlopen(origin+'training-summary.json',timeout=3) as res:summary=json.load(res)
  break
 except Exception:time.sleep(2)
else:raise RuntimeError('Training summary did not become available')
(root/'gpu-full-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('Validation before/after',summary['train_report']['before']['accuracy'],summary['train_report']['after']['accuracy'],flush=True)
records=[]
def download(relative):
 url=origin+relative
 if relative.endswith('/'):
  with urllib.request.urlopen(url,timeout=10) as res:html=res.read().decode()
  parser=Links();parser.feed(html)
  for href in parser.links:
   if '/' in href.rstrip('/') or href.startswith('.') or '?' in href:continue
   download(relative+href)
 else:
  target=root/'full-checkpoint'/relative.removeprefix('checkpoint/');target.parent.mkdir(parents=True,exist_ok=True);digest=hashlib.sha256();size=0
  with urllib.request.urlopen(url,timeout=90) as res,target.open('xb') as out:
   while chunk:=res.read(4*1024*1024):out.write(chunk);digest.update(chunk);size+=len(chunk)
  records.append(dict(file=str(target.relative_to(root/'full-checkpoint')),bytes=size,sha256=digest.hexdigest()));print(relative,size,digest.hexdigest(),flush=True)
download('checkpoint/');(root/'checkpoint-files.json').write_text(json.dumps(records,indent=2)+'\n')
