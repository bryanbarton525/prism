import hashlib,json,shutil,time
from pathlib import Path
start=time.monotonic();srcroot=Path('/serving/routing-adaptation');destroot=Path('/artifacts/routing-adaptation');destroot.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256((srcroot/'2026-10-20-full/checkpoint/model.safetensors').read_bytes()).hexdigest()=='11b9ea87a1431a22f1193e494ba34930ecb8e86832112c83ab3779fd7e5d5019'
manifest=[]
for name in ['2026-10-20-pilot','2026-10-20-full','2026-10-20-curriculum']:
 src=srcroot/name;dst=destroot/name
 if not src.exists():continue
 assert src.parent==srcroot and not dst.exists()
 shutil.copytree(src,dst)
 for path in sorted(src.rglob('*')):
  if path.is_file():
   relative=path.relative_to(src);h1=hashlib.file_digest(path.open('rb'),'sha256').hexdigest();h2=hashlib.file_digest((dst/relative).open('rb'),'sha256').hexdigest();assert h1==h2,(name,str(relative));manifest.append(dict(directory=name,file=str(relative),sha256=h1,bytes=path.stat().st_size))
 shutil.rmtree(src)
print(json.dumps(dict(files=manifest,seconds=time.monotonic()-start,serving_cache=shutil.disk_usage('/serving')._asdict(),artifact_volume=shutil.disk_usage('/artifacts')._asdict())),flush=True)
