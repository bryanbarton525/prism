import gc,json,os,time
from pathlib import Path
import torch
from laya import Router
root=Path(__file__).parent;torch.set_num_threads(2)
router=Router(device='cpu',max_loaded=1)
requests=[json.loads(l) for l in (root/'owner-ablations.jsonl').read_text().splitlines()]
requests=[r for r in requests if r['instructions']=='short' and r['labels'] in ['production','semantic'] and r['state'] in ['production','intent-only']]
with (root/'checkpoint-parity.jsonl').open('x') as out:
 for model in ['english','multilingual']:
  for row in requests:
   p=row['request'];start=time.monotonic();answer=router.predict(p['state'],p['questions'],model=model,max_len=1024,head_max_len=512)
   result=dict(model=model,variant={k:row[k] for k in ['state','instructions','labels']},request=p,response=answer,duration_ms=round((time.monotonic()-start)*1000,2));out.write(json.dumps(result)+'\n');out.flush();print(model,result['variant'],answer['answers'],flush=True)
