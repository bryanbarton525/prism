exec(open('/home/bbarton/prism-eval-results/2026-10-20-bound-routing-fix/probe_owner.py').read().split('with (root/')[0])
states=['Read OPS-314 and tell me who owns it and its current status.','Look up the current status and owner of issue OPS-314.','What is the status and assignee of OPS-314?','Read issue OPS-314.','Change the status of OPS-314.','Do not change the status of OPS-314.','Read OPS-314 and tell me who owns it and its current status. Make no changes.']
with (root/'semantic-ablations.jsonl').open('x') as out:
 for state in states:
  for mode in ['production','no-abstain','descriptive','intent']:
   cs=criteria.copy()
   if mode=='no-abstain':cs.pop('tool_4')
   if mode=='descriptive':cs={'A':'Search historical documentation.','B':'Change an issue record.','C':'Read current issue status and owner.','D':'Read old comments.','E':'None of these.'}
   if mode=='intent':cs={'read':'Read or look up current information.','write':'Change or modify stored information.'}
   payload=dict(model='english',max_len=1024,head_max_len=512,state=state,questions={'tool':dict(type='choice',instructions='What does the user want to do?',criteria=cs)})
   req=urllib.request.Request('https://laya-gpu.iambarton.com/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=10) as res:response=json.load(res)
   row=dict(request=payload,response=response,mode=mode);out.write(json.dumps(row)+'\n');out.flush();print(state,mode,response['answers']['tool']['choice'],flush=True)
