import asyncio,json
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
r=Path(__file__).parent
async def main():
 with (r/'fresh-prism-mcp-host.stderr.log').open('w') as errors:
  async with stdio_client(StdioServerParameters(command='prism',args=['mcp','serve']),errlog=errors) as (read,write):
   async with ClientSession(read,write) as session:
    await session.initialize();listing=await session.list_tools();tools={x.name:x for x in listing.tools};(r/'fresh-prism-mcp-host-tools.json').write_text(json.dumps({k:v.input_schema for k,v in tools.items()},indent=2)+'\n')
    for name,args in [('list_mcp_servers',{}),('list_mcp_server_tools',{'server':'laya-routing','include_schema':True}),('call_mcp_tool',{'server':'laya-routing','tool':'laya_status','arguments':{}})]:
     result=await session.call_tool(name,args);(r/('fresh-prism-'+name+'.json')).write_text(result.model_dump_json(indent=2)+'\n');assert not result.is_error,result;print(name,'OK',flush=True)
    rows=[json.loads(x) for x in (r/'local-routing-mcp-predictions.jsonl').read_text().splitlines()]
    def answer(value):
     if isinstance(value,dict):
      if 'answers' in value:return value
      for child in value.values():
       found=answer(child)
       if found:return found
     if isinstance(value,list):
      for child in value:
       found=answer(child)
       if found:return found
     if isinstance(value,str):
      try:return answer(json.loads(value))
      except (ValueError,TypeError):pass
    predictions=[]
    for row in rows:
     result=await session.call_tool('call_mcp_tool',{'server':'laya-routing','tool':'laya_predict','arguments':row['request']});assert not result.is_error,result
     data=result.model_dump(mode='json');parsed=answer(data);assert parsed,data
     key=parsed['answers']['tool']['choice'];selected=row['request']['questions']['tool']['criteria'][key].split(':',1)[0];assert selected==row['expected'],(selected,row['expected'])
     predictions.append(dict(case=row['case'],stage=row['stage'],selected=selected,expected=row['expected'],response=data))
    (r/'fresh-prism-mcp-host-predictions.json').write_text(json.dumps(predictions,indent=2)+'\n');print('Fresh Prism MCP bridge predictions',len(predictions),'/',len(rows),'passed',flush=True)
asyncio.run(main())
