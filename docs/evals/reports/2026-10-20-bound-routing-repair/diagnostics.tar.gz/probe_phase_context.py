import copy,json,urllib.request
from pathlib import Path
r=Path(__file__).parent;old=r.parent/'2026-10-20-cross-runtime';wire=[json.loads(l)['request'] for l in (r/'candidate-wire.jsonl').read_text().splitlines()];cases=[]
for suite in ['sglang-contract','sglang-independent']:
 for c in json.loads((old/suite/'01-first.json').read_text())['suite']['cases']:
  p=next(p for p in wire if p['state'].split('TASK:\n',1)[1].split('\nCOMPLETED TOOL EVIDENCE',1)[0]==c['task'] and 'call_mcp_tool:' not in p['state']);t=next(t for t in c['tools'] if t.get('required'));cases.append((c['id'],p,t['server']+'.'+t['name'],False))
row=next(json.loads(l) for l in (r/'curriculum-regression-probes.jsonl').read_text().splitlines() if json.loads(l)['case']=='project-between');cases.append(('project-between',row['request'],'projects.get_project',True))
with (r/'phase-context-probes.jsonl').open('x') as out:
 for case,p,expected,completed in cases:
  for variant in ['default','question','state','both']:
   payload=copy.deepcopy(p)
   if variant in ['question','both']:payload['questions']['tool']['instructions']='Choose the next action needed for the task using the completed results. Finish only after the requested records have been retrieved.' if completed else 'Choose the first tool call required by the task. Obtain prerequisite identifiers before following linked records.'
   if variant in ['state','both']:payload['state']=('At least one tool has executed. Follow identifiers from those results before finishing.\n' if completed else 'No tool has executed yet. Choose the initial lookup, not a later dependent lookup.\n')+payload['state']
   req=urllib.request.Request('http://10.43.199.165:8000/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'});answer=json.load(urllib.request.urlopen(req,timeout=10));choice=answer['answers']['tool']['choice'];selected=payload['questions']['tool']['criteria'][choice].split(':',1)[0];record=dict(case=case,variant=variant,request=payload,response=answer,expected=expected,selected=selected,passed=selected==expected);out.write(json.dumps(record)+'\n');out.flush();print(case,variant,selected,record['passed'],flush=True)
