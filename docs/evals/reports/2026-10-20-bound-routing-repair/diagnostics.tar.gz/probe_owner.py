import copy,json,time,urllib.request
from pathlib import Path
root=Path(__file__).parent
wire=Path('/home/bbarton/prism-eval-results/2026-10-20-cross-runtime/laya-wire.jsonl')
base=next(x['request'] for line in wire.read_text().splitlines() if (x:=json.loads(line)).get('method')=='POST' and 'OPS-314' in str(x['request']))
full=base['state'].split('TASK:\n',1)[1].split('\nCOMPLETED TOOL EVIDENCE',1)[0]
q=base['questions']['tool'];criteria=q['criteria']
states={'production':base['state'],'raw':full,'structured':{'task':full,'completed_evidence':[]},'intent-only':full.split('Return the standard envelope')[0].strip()}
instructions={'production':q['instructions'],'short':'Which tool should handle this request?','intent':'What does the user want to do?'}
labels={'production':criteria,'semantic':{v.split(': ',1)[0]:v.split(': ',1)[1] for v in criteria.values()},'description-only':{k:v.split(': ',1)[1] for k,v in criteria.items()},'neutral':{chr(65+i):v.split(': ',1)[1] for i,v in enumerate(criteria.values())}}
with (root/'owner-ablations.jsonl').open('x') as out:
 for state,st in states.items():
  for ins,question in instructions.items():
   for label,cs in labels.items():
    payload=dict(model='english',max_len=1024,head_max_len=512,state=st,questions={'tool':dict(type='choice',instructions=question,criteria=cs)})
    start=time.monotonic();req=urllib.request.Request('https://laya-gpu.iambarton.com/v1/systemone',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=10) as res: response=json.load(res)
    chosen=response['answers']['tool']['choice'];index=list(cs).index(chosen);row=dict(state=state,instructions=ins,labels=label,request=payload,response=response,selected=list(criteria.values())[index].split(': ',1)[0],passed=index==2,duration_ms=round((time.monotonic()-start)*1000,2));out.write(json.dumps(row)+'\n');out.flush()
    print(state,ins,label,row['selected'],row['passed'],flush=True)
