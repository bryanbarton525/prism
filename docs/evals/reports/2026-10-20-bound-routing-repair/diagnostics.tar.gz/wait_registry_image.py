import json,os,re,subprocess,time
from pathlib import Path
r=Path(__file__).parent;tag='ghcr.io/bryanbarton525/laya:sha-a572ff1a29664c1237c36f13c0671cb0b5257270';env=dict(os.environ,DOCKER_CONFIG='/tmp/prism-laya-registry-auth')
for _ in range(180):
 p=subprocess.run(['docker','buildx','imagetools','inspect',tag],env=env,capture_output=True,text=True)
 m=re.search(r'^Digest:\s+(sha256:[a-f0-9]{64})\s*$',p.stdout,re.M)
 if p.returncode==0 and m:
  (r/'published-routing-image.json').write_text(json.dumps(dict(tag=tag,digest=m.group(1),observed=time.time()),indent=2)+'\n');print('Published image verified:',m.group(1),flush=True);break
 time.sleep(5)
else:raise RuntimeError('Image not published within observation window')
